---
aliases:
tags:
  - data/analysis/semanticcode
source:
extract: Five score years ago, a great American, in whose symbolic shadow we stand today, signed the Emancipation Proclamation.
context: This is the opening line of the speech
collection:
themes:
  - "[[Appeal to authority]]"
  - "[[Appeal to tradition]]"
---
 