---
aliases:
tags:
  - data/analysis/theme
description: A rhetorical device aimed and persuading the audience by demonstrating the character or authority of the source.
sub-theme:
  - "[[Appeal to tradition]]"
  - "[[Appeal to authority]]"
---
## Relevant Codes

![[Semantic codes.base#Relevant codes]]

